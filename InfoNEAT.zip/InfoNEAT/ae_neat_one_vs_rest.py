from __future__ import print_function
import os
import sys
import neat
import numpy as np
from math import log
import pickle


def eval_genome(genome, config, data_in, data_out):
    # for genome_id, genome in genomes:
    net = neat.nn.FeedForwardNetwork.create(genome, config)
    sum_score = 0.0

    for xi, xo in zip(data_in, data_out):
        output = net.activate(xi)
        for j in range(len(xo)):
            sum_score += xo[j] * log(1e-15 + output[j])
    mean_sum_score = (1.0 / len(data_out)) * sum_score
    return mean_sum_score

def run(config_file, label_index):
    # Load configuration.
    config = neat.Config(neat.DefaultGenome, neat.DefaultReproduction,
                         neat.DefaultSpeciesSet, neat.DefaultStagnation,
                         config_file)

    # Create the population, which is the top-level object for a NEAT run.
    p = neat.Population(config)

    # Add a stdout reporter to show progress in the terminal.
    p.add_reporter(neat.StdOutReporter(True))
    stats = neat.StatisticsReporter()
    p.add_reporter(stats)
    p.add_reporter(neat.Checkpointer(0))
    p.reporters.reporters[2].filename_prefix = 'neat-checkpoint-'
    p.reporters.reporters[2].index = label_index

    # Run for up to 300 generations.
    num_cpus = int(os.getenv('SLURM_CPUS_ON_NODE', default=1))
    print(f"Parallelizing eval_genome on {num_cpus} cores")
    pe = neat.ParallelEvaluator(num_cpus, eval_genome)
    winner = p.run(pe.evaluate, 15, 1, MNIST_inputs_complete, MNIST_outputs_complete_ohe)

    # Display the winning genome.
    # Display the winning genome.
    print('\nBest genome:{!s} Fitness: {!r}'.format(winner.key, winner.fitness))
    winner_net = neat.nn.FeedForwardNetwork.create(winner, config)
    with open('trained_submodels//net-'+str(label_index), 'wb') as f:
        pickle.dump(winner_net, f)


if __name__ == '__main__':
    # Run index
    run_index = 1
    print(f"Running analysis #{run_index}")
    # Determine path to configuration file. This path manipulation is
    # here so that the script will run successfully regardless of the
    # current working directory.
    local_dir = os.path.dirname(__file__)

    # Load profiling traces
    MNIST_inputs = np.loadtxt("AES_HD/train_X_1.csv")
    ##normalize MNIST_input data
    MNIST_inputs_complete = (MNIST_inputs - np.min(MNIST_inputs)) / (np.max(MNIST_inputs) - np.min(MNIST_inputs))

    config_path = os.path.join(local_dir, 'config-feedforward-exp1')

    # for i in range(4,256):
        # label_class = run_index - 1
    label_class = run_index
    classes = list(range(256))
    classes.remove(label_class)
    # Load profiling labels
    MNIST_outputs_complete = np.loadtxt("AES_HD/train_y_1.csv")
    ## one-hot encoding
    from sklearn.preprocessing import LabelEncoder
    from sklearn.preprocessing import OneHotEncoder

    # define example
    values = np.array(MNIST_outputs_complete)
    # integer encode
    label_encoder = LabelEncoder()
    integer_encoded = label_encoder.fit_transform(values)
    # binary encode
    onehot_encoder = OneHotEncoder(sparse=False)
    integer_encoded = integer_encoded.reshape(len(integer_encoded), 1)
    MNIST_outputs_complete_ohe = onehot_encoder.fit_transform(integer_encoded)
    MNIST_outputs_complete_ohe[:, tuple(classes)] = 0

    run(config_path, label_class)
