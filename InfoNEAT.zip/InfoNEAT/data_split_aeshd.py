from sklearn.model_selection import GroupKFold
import numpy as np
import os
import h5py
import csv
import pickle

in_file = h5py.File("AES_HD//aes_hd.h5", "r")

# Load profiling traces
MNIST_inputs = np.array(in_file['Profiling_traces/traces'], dtype=np.int16) ##changed to np.int16 for variable key dataset
##normalize MNIST_input data
X_profile = (MNIST_inputs - np.min(MNIST_inputs)) / (np.max(MNIST_inputs) - np.min(MNIST_inputs))

# Load attacking labels
Y_profile = list()
with open('AES_HD//labels.csv', newline='') as csvfile:
    spamreader = csv.reader(csvfile, delimiter=' ', quotechar='|')
    for row in spamreader:
        Y_profile.append(int(row[0]))
Y_profile = np.asarray(Y_profile)
metadata = np.array(in_file['Profiling_traces/metadata'])

def batch_data_ovr(x, y, md, m): ### added by Rabin with addition of metadata (md)
    x_batch = list()
    y_batch = list()
    md_batch = list()
    if type(x) is not list and type(y) is not list:
        x = x.tolist()
        y = y.tolist()
        md = md.tolist()
    for j in range(0,256):
        i = 0
        for a, b, c in zip(x, y, md):
            if b == j and i < m:
                x_batch.append(a)
                y_batch.append(b)
                md_batch.append(c)
                i += 1
            if len(x_batch) == m * 256:
                break
    return x_batch, y_batch, md_batch

## label frequency analysis
frequency_labels = list()
for i in range(0,256):
    frequency_labels.append((Y_profile == i).sum())
minimum_frequency = min(frequency_labels)

### get the closest number divisible by 10 to prepare for 10 folds validation
num_folds = 10
frequency_final = minimum_frequency - (minimum_frequency % num_folds)
### create a balanced dataset with all labels having same frequency equal to frequency_final
X,y, md = batch_data_ovr(X_profile, Y_profile, metadata, frequency_final)

## check if the dataset is balanced
for i in range(0,256):
    if (y.count(i) != frequency_final):
        print('Error: dataset not balanced')
        break
X, y, md = np.asarray(X), np.asarray(y), np.asarray(md)
### create the

from sklearn.model_selection import StratifiedKFold
kfold = StratifiedKFold(n_splits=10, shuffle=False, random_state=None)
kfold.get_n_splits(X,y)
# enumerate the splits and summarize the distributions
i = 1
for train_ix, test_ix in kfold.split(X,y):
    # select rows
    train_X, test_X = X[train_ix], X[test_ix]
    train_y, test_y = y[train_ix], y[test_ix]
    train_md, test_md = md[train_ix], md[test_ix]

    with open('AES_HD//train_X_'+str(i)+'.csv', 'w') as FOUT_train:
        np.savetxt(FOUT_train, train_X)
    with open('AES_HD//test_X_'+str(i)+'.csv', 'w') as FOUT_test:
        np.savetxt(FOUT_test, test_X)
    with open('AES_HD//train_y_'+str(i)+'.csv', 'w') as FOUT_trainy:
        np.savetxt(FOUT_trainy, train_y)
    with open('AES_HD//test_y_'+str(i)+'.csv', 'w') as FOUT_testy:
        np.savetxt(FOUT_testy, test_y)
    with open('AES_HD//train_md_'+str(i)+'.txt', 'wb') as FOUT_trainmd:
        pickle.dump(train_md, FOUT_trainmd)
    with open('AES_HD//test_md_'+str(i)+'.txt', 'wb') as FOUT_testmd:
        pickle.dump(test_md, FOUT_testmd)
    i += 1
    print(i)
print('apple')
