import numpy as np
import sys
from sklearn.model_selection import StratifiedShuffleSplit
from sklearn.linear_model import LogisticRegression
import pickle
from joblib import dump, load

def batch_data(x, y, m): ### added by Rabin
    sss = StratifiedShuffleSplit(n_splits=1, test_size = m)
    x_batch = list()
    y_batch = list()
    for i, j in sss.split(np.zeros(len(y)), y):
        for k in j:
            x_batch.append(x[k])
            y_batch.append(y[k])
    return x_batch, y_batch

# create stacked model input dataset as outputs from the ensemble
def stacked_dataset(members, inputX):
    stackX = None
    for net in members:
        # make prediction
        yhat = list()
        for xi in inputX:
            yhat.append(net.activate(xi))
        # yhat = model.predict(inputX, verbose=0)
        # stack predictions into [rows, members, probabilities]
        # print(members.index(net))
        if stackX is None:
            stackX = yhat
        else:
            stackX = np.dstack((stackX, yhat))
    # flatten predictions to [rows, members x probabilities]
    stackX = stackX.reshape((stackX.shape[0], stackX.shape[1]*stackX.shape[2]))
    return stackX

def fit_stacked_model(members, inputX, inputy):
    # create dataset using ensemble
    stackedX = stacked_dataset(members, inputX)
    # fit standalone model
    model = LogisticRegression(multi_class='ovr')
    model.fit(stackedX, inputy)
    return model


run_index = 1
print(f"Running analysis #{run_index}")
X_test = np.loadtxt("AES_HD/train_X_"+str(run_index)+".csv")
Y_test = np.loadtxt("AES_HD/train_y_"+str(run_index)+".csv")
X_attack, Y_attack = batch_data(X_test, Y_test, 20*256)
nets_NEAT = list()
for i in range(0, 256):
    sm = pickle.load(open('models_aeshd/'+str(run_index)+'/net-' + str(i), 'rb'))
    nets_NEAT.append(sm)

# fit stacked model using the ensemble
model_stacked = fit_stacked_model(nets_NEAT, X_attack, Y_attack)

#with open('stacked_model_variable_key//sync//stacked_model_SCA_new150_'+str(run_index), 'wb') as f:
#    pickle.dump(model_stacked, f)
dump(model_stacked, 
'stacked_model_aeshd_20_'+str(run_index))


