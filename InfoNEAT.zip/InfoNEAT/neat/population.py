"""Implements the core evolution algorithm."""
from __future__ import print_function
import random
from neat.reporting import ReporterSet
from neat.math_util import mean
from neat.six_util import iteritems, itervalues
import numpy as np
from sklearn.model_selection import StratifiedShuffleSplit
from sklearn.utils import shuffle

class CompleteExtinctionException(Exception):
    pass


# def batch_data(x, y, m): ### added by Rabin
#     sss = StratifiedShuffleSplit(n_splits=1, test_size = m)
#     x_batch = list()
#     y_batch = list()
#     for i, j in sss.split(np.zeros(len(y)), y):
#         for k in j:
#             x_batch.append(x[k])
#             y_batch.append(y[k])
#     return x_batch, y_batch
# # index_label = list()
# # for a in y_batch:
# #     index_label.append(a.index(max(a)))
# # print(Counter(index_label))

def batch_data_ovr(x, y, m): ### added by Rabin
    x_batch = list()
    y_batch = list()
    x, y = shuffle(x, y)
    x = x.tolist()
    y = y.tolist()
    i, j = 0, 0

    for a, b in zip(x, y):
        if sum(b) == 1 and i < m/2:
            x_batch.append(a)
            y_batch.append(b)
            i += 1
        elif j < m/2:
            x_batch.append(a)
            y_batch.append(b)
            j += 1
        if len(x_batch) == m:
            break
    return x_batch, y_batch

class Population(object):
    """
    This class implements the core evolution algorithm:
        1. Evaluate fitness of all genomes.
        2. Check to see if the termination criterion is satisfied; exit if it is.
        3. Generate the next generation from the current population.
        4. Partition the new generation into species based on genetic similarity.
        5. Go to 1.
    """

    def __init__(self, config, initial_state=None):
        self.reporters = ReporterSet()
        self.config = config
        stagnation = config.stagnation_type(config.stagnation_config, self.reporters)
        self.reproduction = config.reproduction_type(config.reproduction_config,
                                                     self.reporters,
                                                     stagnation)
        if config.fitness_criterion == 'max':
            self.fitness_criterion = max
        elif config.fitness_criterion == 'min':
            self.fitness_criterion = min
        elif config.fitness_criterion == 'mean':
            self.fitness_criterion = mean
        elif not config.no_fitness_termination:
            raise RuntimeError(
                "Unexpected fitness_criterion: {0!r}".format(config.fitness_criterion))

        if initial_state is None:
            # Create a population from scratch, then partition into species.
            self.population = self.reproduction.create_new(config.genome_type,
                                                           config.genome_config,
                                                           config.pop_size)
            self.species = config.species_set_type(config.species_set_config, self.reporters)
            self.generation = 0
            self.species.speciate(config, self.population, self.generation)
        else:
            self.population, self.species, self.generation = initial_state

        self.best_genome = None

    def add_reporter(self, reporter):
        self.reporters.add(reporter)



    def remove_reporter(self, reporter):
        self.reporters.remove(reporter)

    def run(self, fitness_function, n, n_batch, inputs, outputs): # modified to add batch training
        """
        Runs NEAT's genetic algorithm for at most n generations.  If n
        is None, run until solution is found or extinction occurs.

        The user-provided fitness_function must take only two arguments:
            1. The population as a list of (genome id, genome) tuples.
            2. The current configuration object.

        The return value of the fitness function is ignored, but it must assign
        a Python float to the `fitness` member of each genome.

        The fitness function is free to maintain external state, perform
        evaluations in parallel, etc.

        It is assumed that fitness_function does not modify the list of genomes,
        the genomes themselves (apart from updating the fitness member),
        or the configuration object.
        """

        if self.config.no_fitness_termination and (n is None):
            raise RuntimeError("Cannot have no generational limit with no fitness termination")

        k = 0


        while n is None or k < n:
            k += 1

            self.reporters.start_generation(self.generation)

            ##added by Rabin
            if n_batch == 0:
                fitness_function(list(iteritems(self.population)), self.config, inputs, outputs)  ### modified by Rabin

            elif n % n_batch == 0:
                input_batch, output_batch = batch_data_ovr(inputs, outputs, 256)
                # input_batch, output_batch = batch_data(inputs, outputs, 100)
                fitness_function(list(iteritems(self.population)), self.config, input_batch, output_batch)  ### modified by Rabin
            ##############

            best = None
            #for g in itervalues(self.population):
            for g in itervalues(self.population):
                if g.fitness is None:
                    raise RuntimeError("Fitness not assigned to genome {}".format(g.key))

                if best is None or g.fitness > best.fitness:
                    best = g
            self.reporters.post_evaluate(self.config, self.population, self.species, best)

            # Track the best genome ever seen.
            if self.best_genome is None or best.fitness > self.best_genome.fitness:
                self.best_genome = best

            if not self.config.no_fitness_termination:
                # End if the fitness threshold is reached.
                fv = self.fitness_criterion(g.fitness for g in itervalues(self.population))
                if fv >= self.config.fitness_threshold:
                    self.reporters.found_solution(self.config, self.generation, best)
                    break

            # Create the next generation from the current generation.
            self.population = self.reproduction.reproduce(self.config, self.species,
                                                          self.config.pop_size, self.generation)

            # Check for complete extinction.
            if not self.species.species:
                self.reporters.complete_extinction()

                # If requested by the user, create a completely new population,
                # otherwise raise an exception.
                if self.config.reset_on_extinction:
                    self.population = self.reproduction.create_new(self.config.genome_type,
                                                                   self.config.genome_config,
                                                                   self.config.pop_size)
                else:
                    raise CompleteExtinctionException()

            # Divide the new population into species.
            self.species.speciate(self.config, self.population, self.generation)

            self.reporters.end_generation(self.config, self.population, self.species)

            self.generation += 1

        if self.config.no_fitness_termination:
            self.reporters.found_solution(self.config, self.generation, self.best_genome)

        return self.best_genome
